<?php

$route['default_controller'] = 'home';
$route['register/bank-information'] = 'register/bankinformation';
$route['register/contact-information'] = 'register/contactinformation';

$route['home/my-caravans'] = 'home/mycaravans';
$route['home/add-caravan'] = 'home/addcaravan';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
