<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();
		if (!$this->session->userdata('logged')) {
			if ($this->uri->segment(2)) {
				if ($this->uri->segment(2)!='login'){
					redirect('home');
				}
			}
		}
		else {
			if (!$this->uri->segment(2)) {
				if ($this->session->userdata('userinformation')->status!='active') {
					redirect('home/deactive');
				}
				else {
					redirect('home/dashboard');	
				}
			}
		}
	}

	public function index()
	{
		$this->load->view('inc/header');
		$this->load->view('pages/login');
		$this->load->view('inc/footer');
	}

	public function login() {
		$this->load->model('vt');
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$result = $this->vt->checklogin($email,$password);
		if ($result) {
			$this->session->set_userdata('logged', true);
			$this->session->set_userdata('userinformation', $result);
			redirect('home');
		} else {
			$this->session->set_flashdata('information', '<div class="alert mt-5 alert-danger m-auto alert-dismissible fade show" role="alert"><strong>Üzgünüz!</strong> Kullanıcı adı veya parola hatalı. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button></div>');
				redirect ('home');

		}
	}

	public function deactive() {
		$data['userinformation'] = $this->session->userdata('userinformation');
		$this->load->view('inc/header');
		$this->load->view('inc/deactive', $data);
		$this->load->view('inc/footer');
	}

	public function dashboard() {
		$data['userinformation'] = $this->session->userdata('userinformation');
		$this->load->view('inc/header');
		$this->load->view('dashboard/home', $data);
		$this->load->view('inc/footer');
	}
	public function profile() {
		$data['userinformation'] = $this->session->userdata('userinformation');
		$this->load->view('inc/header');
		$this->load->view('dashboard/profile', $data);
		$this->load->view('inc/footer');
	}
		public function mycaravans() {	
    		$data['company_information'] = $this->session->userdata('company_information');
    		$this->load->view('inc/header');
    		$this->load->view('dashboard/my-caravans',$data);
    		$this->load->view('inc/footer');
	    }
	    
	    public function addcaravan() {	
    		$data['company_information'] = $this->session->userdata('company_information');
    		$this->load->view('inc/header');
    		$this->load->view('dashboard/add-caravan',$data);
    		$this->load->view('inc/footer');
	    }
}
