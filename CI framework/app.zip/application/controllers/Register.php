<?php

class Register extends CI_Controller {

	public function index()
	{	
		$data['company_information'] = $this->session->userdata('company_information');
		$this->load->view('inc/header');
		$this->load->view('pages/register/company-information',$data);
		$this->load->view('inc/footer');
	}
    
	public function verifyregister() {
		$company_name 		= $this->input->post('company_name');
		$company_holder 	= $this->input->post('company_holder');
		$company_address 	= $this->input->post('company_address');
		$caravan_number 	= $this->input->post('caravan_number');
		$tax_administration = $this->input->post('tax_administration');
		$tax_number 		= $this->input->post('tax_number');
		$tax_plate 			= $this->input->post('tax_plate');
		$rental_agreement 	= $this->input->post('rental_agreement');
		$company_our 		= $this->input->post('company_our');

		$data = array (
			'company_name' 			=> $company_name,
			'company_holder' 		=> $company_holder,
			'company_address' 		=> $company_address,
			'caravan_number' 		=> $caravan_number,
			'tax_administration' 	=> $tax_administration,
			'tax_number' 			=> $tax_number,
			'tax_plate' 			=> $tax_plate,
			'rental_agreement' 		=> $rental_agreement,
			'company_our' 			=> $company_our
		);

		$this->session->set_userdata('company_information', $data);
		redirect('register/bank-information');
	}

		public function bankinformation() {
			$data['company_information'] = $this->session->userdata('company_information');
			$data['bank_information'] = $this->session->userdata('bank_information');
			if ($this->session->userdata('company_information')) {
				$this->load->view('inc/header');
				$this->load->view('pages/register/bank-information',$data);
				$this->load->view('inc/footer');
			}else {
				redirect('register');
			}
		}

		public function verifybank() {
			$bank_account_holder 	= $this->input->post('bank_account_holder');
			$bank_name 				= $this->input->post('bank_name');
			$iban 					= $this->input->post('iban');
				
			$data = array (
			'bank_account_holder' 	=> $bank_account_holder,
			'bank_name' 			=> $bank_name,
			'iban' 					=> $iban,
			);
			
			$this->session->set_userdata('bank_information', $data);
			redirect('register/contact-information');
		}
 
		public function contactinformation() {
			$data['company_information'] = $this->session->userdata('company_information');
			$data['bank_information'] = $this->session->userdata('bank_information');
			if ($this->session->userdata('bank_information')) {
				$this->load->view('inc/header');
				$this->load->view('pages/register/contact-information',$data);
				$this->load->view('inc/footer');
			}else {
				redirect('register/bank-information');
			}
		}

		public function createaccount() {
			$data['company_information'] 	= $this->session->userdata('company_information');
			$data['bank_information'] 		= $this->session->userdata('bank_information');
			$company_name 					= $this->session->userdata('company_information')['company_name'];
			$company_holder 				= $this->session->userdata('company_information')['company_holder'];
			$company_address 				= $this->session->userdata('company_information')['company_address'];
			$caravan_number 				= $this->session->userdata('company_information')['caravan_number'];
			$tax_administration 			= $this->session->userdata('company_information')['tax_administration'];
			$tax_number 					= $this->session->userdata('company_information')['tax_number'];
			$tax_plate 						= $this->session->userdata('company_information')['tax_plate'];
			$rental_agreement 				= $this->session->userdata('company_information')['rental_agreement'];
			$company_our 					= $this->session->userdata('company_information')['company_our'];
			$bank_account_holder 			= $this->session->userdata('bank_information')['bank_account_holder'];
			$bank_name 						= $this->session->userdata('bank_information')['bank_name'];
			$iban 							= $this->session->userdata('bank_information')['iban'];
			$email 							= $this->input->post('email');
			$mobile 						= $this->input->post('phone');
			$password 						= $this->input->post('password');
			$website 						= $this->input->post('website');
			$socialmedia 					= $this->input->post('socialmedia');
			$created_at						= date('y-m-d h-i-s');

			$data['company'] = array (
				'company_name' 			=> $company_name,
				'company_holder' 		=> $company_holder,
				'address' 				=> $company_address,
				'caravan_number' 		=> $caravan_number,
				'tax_administration' 	=> $tax_administration,
				'tax_number' 			=> $tax_number,
				'tax_plate' 			=> $tax_plate,
				'rental_agreement' 		=> $rental_agreement,
				'description' 			=> $company_our,
				'bank_account_holder' 	=> $bank_account_holder,
				'bank_name' 			=> $bank_name,
				'iban' 					=> $iban,
				'email' 				=> $email,
				'mobile' 				=> $mobile,
				'password' 				=> md5($password),
				'website' 				=> $website,
				'socialmedia' 			=> $socialmedia,
				'status' 				=> 'deactive',
				'created_at'			=> $created_at
			);
			$this->db->insert('users', $data['company']);
			$this->session->sess_destroy();
			redirect('home');
		}
		

	public function getsession() {
		print_r($this->session->userdata('bank_information'));
	}
	public function logout() {
		$this->session->sess_destroy();
		redirect('home');
	}
}
