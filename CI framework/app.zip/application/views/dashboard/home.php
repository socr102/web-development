<div class="container my-5">
    <div class="row d-flex">
        <h1 class="fs-4 px-0">Dashboard</h1>
    </div>
    <div class="row bg-white p-5 rounded-3 border">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <p class="m-0 fw-bold">Rezervasyon</p>
                    <p class="fs-1 fw-bold lh-1">12</p>
                </div>
                <div class="col-md-6 col-sm-12">
                    <p class="m-0 fw-bold">Ortalama Yanıt Süresi</p>
                    <p class="fs-1 fw-bold lh-1">34 <small style="font-size:13px;position:absolute;line-height:2em;margin-left:15px;">DAKİKA</small></p>
                </div>
                <div class="col-md-6 col-sm-12">
                    <p class="m-0 fw-bold">Kazanç</p>
                    <p class="fs-1 fw-bold lh-1">17,035 <small style="font-size:20px;">₺</small></p>
                </div>
                <div class="col-md-6 col-sm-12">
                    <p class="m-0 fw-bold">Ortalama Puan</p>
                    <p class="fs-1 fw-bold lh-1">4,3 <svg style="position:absolute;margin-left:15px" width="25" height="25" viewBox="0 0 29.777 28.5"><path d="M33.79.979,30.156,8.348,22.025,9.533a1.782,1.782,0,0,0-.985,3.039L26.922,18.3l-1.391,8.1a1.78,1.78,0,0,0,2.582,1.876l7.274-3.824,7.274,3.824A1.781,1.781,0,0,0,45.245,26.4l-1.391-8.1,5.883-5.733a1.782,1.782,0,0,0-.985-3.039L40.62,8.348,36.985.979a1.783,1.783,0,0,0-3.195,0Z" transform="translate(-20.5 0.013)" fill="#ffb100"/></svg>
</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            Deneme
        </div>
    </div>
</div>