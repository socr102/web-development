



<div class="container my-5">
    <div class="row">
        <div class="col-sm-6 mb-3">
            <h1 class="fs-5 fw-bold">Karavanlarım</h1>
        </div>
        <div class="col-sm-6 mb-3">
            <a href="<?php echo base_url('home/add-caravan') ?>" class="btn btn-primary float-end px-4" style="height:40px;line-height:1.8em"><svg style="margin-top:-3px;margin-left:0" width="10" height="10" viewBox="0 0 14.587 14.587"><path d="M13.545,37.731H8.857V33.042A1.042,1.042,0,0,0,7.815,32H6.773a1.042,1.042,0,0,0-1.042,1.042v4.689H1.042A1.042,1.042,0,0,0,0,38.773v1.042a1.042,1.042,0,0,0,1.042,1.042H5.731v4.689a1.042,1.042,0,0,0,1.042,1.042H7.815a1.042,1.042,0,0,0,1.042-1.042V40.857h4.689a1.042,1.042,0,0,0,1.042-1.042V38.773A1.042,1.042,0,0,0,13.545,37.731Z" transform="translate(0 -32)"/></svg> &nbsp;&nbsp;&nbsp;Karavan Ekle</a>
        </div>
        
        <?php $authorid = $this->session->userdata('userinformation')->id; 
        $query = $this->db->where('author', $authorid)->get("car");

        foreach ($query->result() as $row) { ?>
        
        <div class="col-sm-3 mb-4">
            <div class="card p-3">
                <img class="w-100 rounded-3" src="<?php if($media = $this->db->where('media_id', $row->thumbnail_id)->get('media')->row()) { 
                    if ($media->partner==0);
                    echo 'https://test.karavan360.com/' . $media->media_url;
                 } ?>">
                <p class="mt-2 mb-2 fw-bold"><?php echo $row->post_title; ?></p>
                <a class="btn btn-secondary w-100" style="height:40px;line-height:1.5em"><svg width="19.007" height="16.898" viewBox="0 0 19.007 16.898"><path d="M13.275,11.309l1.056-1.056a.265.265,0,0,1,.452.188v4.8A1.584,1.584,0,0,1,13.2,16.823H1.584A1.584,1.584,0,0,1,0,15.239V3.623A1.584,1.584,0,0,1,1.584,2.039h9.025a.266.266,0,0,1,.188.452L9.741,3.547a.262.262,0,0,1-.188.076H1.584V15.239H13.2V11.494A.26.26,0,0,1,13.275,11.309ZM18.443,4.65,9.778,13.315l-2.983.33a1.363,1.363,0,0,1-1.5-1.5l.33-2.983L14.285.492a1.926,1.926,0,0,1,2.729,0L18.44,1.917a1.933,1.933,0,0,1,0,2.732Zm-3.26,1.02L13.266,3.752,7.134,9.887l-.241,2.155L9.048,11.8Zm2.138-2.63L15.9,1.614a.345.345,0,0,0-.488,0l-1.02,1.02L16.3,4.551l1.02-1.02A.352.352,0,0,0,17.321,3.039Z" transform="translate(0 0.075)"/></svg>
 Karavanı Düzenle</a>
            </div>
        </div>
        
        <?php } ?>
    </div>
</div>