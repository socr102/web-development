<?php
$id = $this->session->userdata('userinformation')->id;
$row = $this->db->where('id', $id)->get('users')->row();
 ?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-9 ps-0 col-sm-12">
            <div class="card">
                <div class="card-heder p-3 border-bottom">
                    <h1 class="fs-6 m-0">Detaylar</h1>
                </div>
                <?php echo $row->id ?>
                <div class="card-body">
                    <form class="row needs-validation" novalidate action="">
                        <div class="col-md-6 mb-3">
                            <label for="company_name" class="form-label">Şirket Adı</label>
                            <input type="text" class="form-control" id="company_name" required value="<?php echo $row->company_name; ?>">
                            <div class="invalid-feedback">
                                Lütfen şirket adını doldurun.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="company_holder" class="form-label">Şirket Yetkilisi</label>
                            <input type="text" class="form-control" id="company_holder" required value="<?php echo $row->company_holder; ?>">
                            <div class="invalid-feedback">
                                Lütfen şirket yetkilisini belirtin.
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="tax_administration" class="form-label">Vergi Dairesi</label>
                            <input type="text" class="form-control" id="tax_administration" readonly value="<?php echo $row->tax_administration; ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="tax_number" class="form-label">Vergi No</label>
                            <input type="text" class="form-control" id="tax_number" readonly value="<?php echo $row->tax_number; ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="company_address" class="form-label">Şirketin tam adresi</label>
                            <input type="text" class="form-control" id="company_address" required value="<?php echo $row->address; ?>">
                            <div class="invalid-feedback">
                                Lütfen şirket adresini belirtin.
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="bank_name" class="form-label">Banka </label>
                            <input type="text" class="form-control" id="bank_name" readonly value="<?php echo $row->bank_name; ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="bank_account_holder" class="form-label">Hesap sahibi</label>
                            <input type="text" class="form-control" id="bank_account_holder" readonly value="<?php echo $row->bank_account_holder; ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="iban" class="form-label">IBAN</label>
                            <input type="text" class="form-control" id="iban" readonly value="<?php echo $row->iban; ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="company_address" class="form-label">Konum İl / İlçe</label>
                            <input type="text" class="form-control" id="company_address" required>
                            <div class="invalid-feedback">
                                Lütfen konum bilgisini belirtin.
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="phone" class="form-label">Telefon Numarası</label>
                            <input type="text" class="form-control" id="phone" value="<?php echo $row->mobile; ?>" readonly>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="email" class="form-label">E-Posta Adresi</label>
                            <input type="text" class="form-control" id="email" value="<?php echo $row->email; ?>" readonly>
                        </div>
                        <p style="color:#777777;font-size:12px;"><svg class="me-2" width="15.5" height="15.5" viewBox="0 0 15.5 15.5"><path d="M15.75,8a7.75,7.75,0,1,0,7.75,7.75A7.751,7.751,0,0,0,15.75,8Zm0,3.438a1.313,1.313,0,1,1-1.313,1.313A1.312,1.312,0,0,1,15.75,11.438Zm1.75,7.938a.375.375,0,0,1-.375.375h-2.75A.375.375,0,0,1,14,19.375v-.75a.375.375,0,0,1,.375-.375h.375v-2h-.375A.375.375,0,0,1,14,15.875v-.75a.375.375,0,0,1,.375-.375h2a.375.375,0,0,1,.375.375V18.25h.375a.375.375,0,0,1,.375.375Z" transform="translate(-8 -8)" fill="#777" opacity="0.334"/></svg>Bazı bilgiler bizim kontrolümüzden geçmeden düzenlenemez. Banka ve İletişim bilgileri gibi bilgileri değiştirmek istiyorsanız lütfen bizimle geçin.</p>
                        <div class="col-md-12">
                        <button class="btn btn-primary w-25 float-end">Değişiklikleri Kaydet </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-4 col-sm-12">

        </div>
    </div>
</div>