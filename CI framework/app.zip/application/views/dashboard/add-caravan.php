    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-3 col-sm-12 px-0">
                <h1 class="fs-5 mb-4 fw-bold">Yeni Karavan Ekle</h1>
                <div class="p-3 card">
                    <ul class="nav nav-tabs d-block border-0" id="CaravanAddTab" role="tablist">
                      <li class="nav-item add-caravan-button" role="presentation">
                        <button class="nav-link active w-100 add-caravan-link d-flex justify-content-start rounded-3" id="temel-tab" data-bs-toggle="tab" data-bs-target="#temel" type="button" role="tab" aria-controls="temel" aria-selected="true">
                            <span style="font-size:60px;font-weight:bold;margin-left:20px;">1</span>
                            <div class="d-block mt-3 ms-4">
                                <p class="p-0 m-0 text-start"><b>Temel Bilgiler</b></p>
                                <p class="p-0 m-0 text-start">Karavanınız hakkında<br>temel bilgiler</p>
                            </div>
                        </button>
                      </li>
                      <li class="nav-item add-caravan-button" role="presentation">
                        <button class="nav-link w-100 add-caravan-link d-flex justify-content-start rounded-3" id="location-tab" data-bs-toggle="tab" data-bs-target="#location" type="button" role="tab" aria-controls="location" aria-selected="true">
                            <span style="font-size:60px;font-weight:bold;margin-left:20px;">2</span>
                            <div class="d-block mt-3 ms-4">
                                <p class="p-0 m-0 text-start"><b>Konum</b></p>
                                <p class="p-0 m-0 text-start">Karavanın konumunu<br>belirleyin</p>
                            </div>
                        </button>
                      </li>
                      <li class="nav-item add-caravan-button" role="presentation">
                        <button class="nav-link w-100 add-caravan-link d-flex justify-content-start rounded-3" id="price-tab" data-bs-toggle="tab" data-bs-target="#price" type="button" role="tab" aria-controls="price" aria-selected="true">
                            <span style="font-size:60px;font-weight:bold;margin-left:20px;">3</span>
                            <div class="d-block mt-3 ms-4">
                                <p class="p-0 m-0 text-start"><b>Fiyat</b></p>
                                <p class="p-0 m-0 text-start">Karavanınızı<br>fiyatlandırın</p>
                            </div>
                        </button>
                      </li>
                      <li class="nav-item add-caravan-button" role="presentation">
                        <button class="nav-link w-100 add-caravan-link d-flex justify-content-start rounded-3" id="detail-tab" data-bs-toggle="tab" data-bs-target="#detail" type="button" role="tab" aria-controls="detail" aria-selected="true">
                            <span style="font-size:60px;font-weight:bold;margin-left:20px;">4</span>
                            <div class="d-block mt-3 ms-4">
                                <p class="p-0 m-0 text-start"><b>İlan Detayları</b></p>
                                <p class="p-0 m-0 text-start">Karavan ilanınızın<br>detaylarını girin</p>
                            </div>
                        </button>
                      </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-12 mt-5 px-2">
                <form>
                <div class="tab-content" id="CaravanAddTabContent">
                  <div class="tab-pane fade card p-5 show active" id="temel" role="tabpanel" aria-labelledby="temel-tab">
                        <h2 class="fs-5 fw-bold">Temel Bilgiler</h2>
                            <p><small>Karavanınız hakkında misafirinizin bilmesini istediğini tüm bilgileri girin. Tüm konularla seffaf olmaya çalışın ve sizin karavanınızın öne çıkan özelliklerinden mutlaka bahsedin.</small></p>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                              <label for="caravan_title" class="form-label">İlanınıza ilgi çekici bir başlık girin</label>
                              <input type="text" class="form-control" name="caravan_title" id="caravan_title" placeholder="Karavanım çok güzel">
                            </div>
                            <div class="col-md-12 mb-3">
                              <label for="caravan_detail" class="form-label">Detaylar</label>
                              <textarea class="form-control" name="caravan_detail" id="caravan_detail" placeholder="Misafirlere karavanınızdan bahsedin" rows="3"></textarea>
                            </div>
                            <div class="col-md-12 mb-3">
                              <label for="caravan_detail" class="form-label">Misafire tavsiyelerde bulun</label>
                              <textarea class="form-control" name="caravan_detail" id="caravan_detail" placeholder="Yola çıkmadan önce mutlaka…" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                              <label for="caravan_brand" class="form-label">Karavanın markası</label>
                              <input type="text" class="form-control" name="caravan_brand" id="caravan_brand" placeholder="Başlık…">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="caravan_type" class="form-label">Karavanın türü</label>
                                <select class="form-select" name="caravan_type" id="caravan_type" aria-label="Default select example">
                                  <option selected disabled>Seç</option>
                                  <option value="1">One</option>
                                  <option value="2">Two</option>
                                  <option value="3">Three</option>
                                </select>
                            </div>
                        </div>
                  </div>
                  <div class="tab-pane fade card p-5" id="location" role="tabpanel" aria-labelledby="location-tab">
                      <h2 class="fs-5 fw-bold">Konum</h2>
                            <p><small>Konum bilgisi sizin karavanınızın nereden teslim alınacağı ve nereye teslim edileceği bilgisidir. Konumda doğru işaretlediğinizden emin olun.</small></p>
                        <hr>
                        
                        <link href="https://api.mapbox.com/mapbox-gl-js/v2.2.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v2.2.0/mapbox-gl.js"></script>


<div id="map"></div>
<pre id="coordinates" class="coordinates"></pre>
                    <div>
                        <input type="hidden" name="lng" id="Lng">
                        <input type="hidden" name="lat" id="Lat">
                    </div>
                    <div class="col-md-12 mt-3">
                        <label for="caravan_brand" class="form-label">Tam adres</label>
                        <input type="text" class="form-control" name="caravan_brand" id="caravan_brand" placeholder="Örnek sokak, Örnek cadde no 1 İl/İlçe">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3 mt-3">
                        <label for="caravan_brand" class="form-label">Ülke</label>
                        <input type="text" class="form-control" name="caravan_brand" id="caravan_brand" placeholder="Ülke…">
                    </div>
                    <div class="col-md-6 mb-3 mt-3">
                        <label for="caravan_brand" class="form-label">Şehir</label>
                        <input type="text" class="form-control" name="caravan_brand" id="caravan_brand" placeholder="Şehir…">
                    </div>
                    </div>
                    
                  </div>
                  <div class="tab-pane fade card p-5" id="price" role="tabpanel" aria-labelledby="price-tab">
                      <h2 class="fs-5 fw-bold">Fiyat</h2>
                            <p><small>Karavanınızın kiralama bedelini belirlemede özgürsünüz. Biz Karavan360 olarak size ek gelir sağlamak isterken aynı zamanda misafirlere ulaşılabilir fiyatlarda bir karavan deneyimi sunmayı hedefliyoruz. Platformumuzda uygun fiyatlarda karavanlar daha çok tercih ediliyor.</small></p>
                        <hr>
                        <div class="row">
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Günlük Kiralama Bedeli</label>
                                <input type="text" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="deposit" class="form-label">Depozito</label>
                                <input type="text" class="form-control" name="deposit" id="deposit" placeholder="Depozito">
                            </div>
                            <p>Dönemlik Kiralama Bedelleri <small>(Günlük Fiyatlandırma)</small></p>
                            <div class="col-md-4 mb-3 mt-3">
                                <label for="price_7" class="form-label"><small>Haftalık (7 gün ve üzeri)</small></label>
                                <input type="text" class="form-control" name="price_7" id="price_7" placeholder="350">
                            </div>
                            <div class="col-md-4 mb-3 mt-3">
                                <label for="price_30" class="form-label"><small>Aylık (30 gün ve üzeri)</small></label>
                                <input type="text" class="form-control" name="price_30" id="price_30" placeholder="310">
                            </div>
                    </div>
                  </div>
                  
                  <div class="tab-pane fade card p-5" id="detail" role="tabpanel" aria-labelledby="detail-tab">
                       <h2 class="fs-5 fw-bold">İlan detayları</h2>
                            <p><small>Karavanınızla ilgili tüm detayları belirtin ve şeffaf olun. Yanlış bilgi girmemeye özen gösterin. Müşteri ummadığı bir durumla karşılaşırsa İptal talebi oluşturabilir.</small></p>
                        <hr>
                        <div class="row">
                            <div class="form-check ps-0 col-md-6">
                              <input class="form-check-input ms-3" type="checkbox" name="smoke" id="smoke">
                              <label class="form-check-label mt-2 ms-3" for="smoke">
                                Sigara içilebilir mi?
                              </label>
                            </div>
                            <div class="form-check col-md-6">
                              <input class="form-check-input" type="checkbox" name="driver" id="driver">
                              <label class="form-check-label mt-2 ms-3" for="driver">
                                Ek sürücüye izin var mı?
                              </label>
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="caravan_type" class="form-label">Ehliyet Tipi</label>
                                <select class="form-select" name="caravan_type" id="caravan_type" aria-label="Default select example">
                                  <option selected disabled>Seç</option>
                                  <option value="1">One</option>
                                  <option value="2">Two</option>
                                  <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="caravan_type" class="form-label">Vites Tipi</label>
                                <select class="form-select" name="caravan_type" id="caravan_type" aria-label="Default select example">
                                  <option selected disabled>Seç</option>
                                  <option value="1">One</option>
                                  <option value="2">Two</option>
                                  <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Yolcu Sayısı</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Yatak Sayısı</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Karavan uzunluğu (Metre)</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Ortalama yakıt (LT/100KM)</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Maksimum KM Sınırı</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="price" class="form-label">Sınır aşılırsa KM başına ücret</label>
                                <input type="number" class="form-control" name="price" id="price" placeholder="Fiyat">
                            </div>
                        </div>
                  </div>
                  
                  
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                </div>
                </form>
            </div>
            <div class="col-md-3 px-0 mt-5 col-sm-12">
                <div class="card p-3">
                    Fotoğraf
                    <p class="m-0 my-1"><span>Şehir</span> • <span>Karavan Türü</span></p>
                    <p class="m-0 mb-1 fw-bold">Karavanım çok güzel</p>
                    <p class="m-0 fw-bold text-primary">000₺</p>
                </div>
            </div>
        </div>
    </div>
    
    
    
    
    
    
    <script>
	// TO MAKE THE MAP APPEAR YOU MUST
	// ADD YOUR ACCESS TOKEN FROM
	// https://account.mapbox.com
	mapboxgl.accessToken = 'pk.eyJ1IjoiYWhtZXRhbHRheSIsImEiOiJja29naXh3eTAwMTN1MnBqejZzc2N1bHk5In0.2IKDRAbE8u5T7VY0uc_CSg';
var coordinates = document.getElementById('coordinates');
var map = new mapboxgl.Map({
container: 'map',
style: 'mapbox://styles/mapbox/streets-v11',
center: [32.85759324686623, 39.911436649030804],
zoom: 4
});
 
var marker = new mapboxgl.Marker({
draggable: true
})
.setLngLat([32.85759324686623, 39.911436649030804])
.addTo(map);
 
function onDragEnd() {
var lngLat = marker.getLngLat();
coordinates.style.display = 'none';
    document.getElementById("Lng").value = lngLat.lng;
    document.getElementById("Lat").value = lngLat.lat;
    
}
 
marker.on('dragend', onDragEnd);
map.addControl(new mapboxgl.FullscreenControl());
map.addControl(new mapboxgl.NavigationControl());

function Save() {
  
}

</script>
<style>
#map {min-width: 100%; height:300px;border: 1px solid #DDDDDD;border-radius:0.50rem; }
.coordinates {
background: rgba(0, 0, 0, 0.5);
color: #fff;
position: absolute;
bottom: 40px;
left: 10px;
padding: 5px 10px;
margin: 0;
font-size: 11px;
line-height: 18px;
border-radius: 3px;
display: none;
}
</style>