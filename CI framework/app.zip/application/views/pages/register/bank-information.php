<div class="container mb-5">
    <div class="row">
        <div class="col-sm-12 px-0">
            <h1 class="fs-3 fw-bold mt-5 mb-0">Karavan360 Partner Başvurusu</h1>
            <div class="my-4">
                <ul class="list-unstyled d-flex">
                    <li><a class="btn btn-step px-5 disabled">Şirket Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#d1d1d1"/></svg></li>
                    <li><a class="btn btn-step px-5">Banka Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#5f4fa1"/></svg></li>
                    <li><a class="btn btn-step px-5 disabled">İletişim Bilgileri</a></li>
                </ul>
            </div>
        </div>
        <div class="card mb-5">
            <div class="row p-5">
                <div class="col-md-7 col-sm-12">
                    <form action="<?php echo base_url('register/verifybank') ?>" method="post" class="needs-validation row" novalidate enctype="multipart/form-data">
                        <div class="col-md-12 col-sm-12 mb-3">
                            <label for="bank_account_holder" class="form-label">Hesap Sahibi</label>
                            <input type="text" class="form-control" name="bank_account_holder" id="bank_account_holder" placeholder="Ad Soyad / Şirket Adı / Ünvan" required value="<?php if (isset($bank_information['bank_account_holder'])) {echo $bank_information['bank_account_holder'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen banka hesabı sahibini giriniz.
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-3">
                            <label for="bank_name" class="form-label">Banka</label>
                            <select class="form-select" name="bank_name" id="bank_name" required>
                                <?php if (isset($bank_information['bank_name'])) {
                                    echo '<option selected>' . $bank_information['bank_name'] . '</option>';
                                } else {
                                    echo '<option selected disabled value="">Lütfen Banka Seçiniz</option>';
                                } ?>
                            <option>...</option>
                            </select>
                            <div class="invalid-feedback">
                                Lütfen ödeme almak istediğiniz banka'yı seçiniz.
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-3">
                            <label for="iban" class="form-label">IBAN</label>
                            <input type="text" class="form-control" name="iban" id="iban" required value="<?php if (isset($bank_information['iban'])) {echo $bank_information['iban'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen şirketin tam adresini giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <a href="<?php echo base_url('register') ?>" class="btn btn-secondary px-5 rounded-5 float-start"> Geri</a>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <button type="submit" class="btn btn-primary px-5 rounded-5 float-end">İleri </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-5 col-sm-12">
                    <img src="<?php echo base_url('assets/image/company-information.png') ?>" class="w-100 my-auto" alt="">
                </div>
            </div>
        </div>
    </div>
</div>