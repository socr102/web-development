<div class="container mb-5">
    <div class="row">
        <div class="col-sm-12 px-0">
            <h1 class="fs-3 fw-bold mt-5 mb-0">Karavan360 Partner Başvurusu</h1>
            <div class="my-4">
                <ul class="list-unstyled d-flex">
                    <li><a class="btn btn-step px-5">Şirket Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#5f4fa1"/></svg></li>
                    <li><a class="btn btn-step px-5 disabled">Banka Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#d1d1d1"/></svg></li>
                    <li><a class="btn btn-step px-5 disabled">İletişim Bilgileri</a></li>
                </ul>
            </div>
        </div>
        <div class="card mb-5">
            <div class="row p-5">
                <div class="col-md-7 col-sm-12">
                    <form action="<?php echo base_url('register/verifyregister') ?>" method="post" class="needs-validation row" novalidate enctype="multipart/form-data">
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="company-name" class="form-label">Şirket Adı</label>
                            <input type="text" class="form-control" name="company_name" id="company-name" placeholder="ABC Karavan" required value="<?php if (isset($company_information['company_name'])) {echo $company_information['company_name'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen şirket adını giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="company-holder" class="form-label">Yetkili</label>
                            <input type="text" class="form-control" name="company_holder" id="company-holder" placeholder="Ad Soyad" required value="<?php if (isset($company_information['company_holder'])) {echo $company_information['company_holder'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen yetkili adı ve soyadını giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="company-address" class="form-label">Şirketin tam adresi</label>
                            <input type="text" class="form-control" name="company_address" id="company-address" placeholder="Örnek sokak, Örnek cadde no 1 İlçe/İl" required value="<?php if (isset($company_information['company_address'])) {echo $company_information['company_address'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen şirketin tam adresini giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="caravan-number" class="form-label">Karavan sayısı</label>
                            <input type="text" class="form-control" name="caravan_number" id="caravan-number" placeholder="Filonuzdaki karavan sayısı" required value="<?php if (isset($company_information['caravan_number'])) {echo $company_information['caravan_number'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen filonuzda bulunan karavan sayısını giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="tax-administration" class="form-label">Vergi dairesi</label>
                            <input type="text" class="form-control" name="tax_administration" id="tax-administration" placeholder="Kadıköy" required value="<?php if (isset($company_information['tax_administration'])) {echo $company_information['tax_administration'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen vergi dairenizi giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="tax-number" class="form-label">Vergi numarası</label>
                            <input type="text" class="form-control" name="tax_number" id="tax-number" placeholder="01010" required value="<?php if (isset($company_information['tax_number'])) {echo $company_information['tax_number'];}  ?>">
                            <div class="invalid-feedback">
                                Lütfen Vergi numaranızı giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="tax_plate" class="form-label">Vergi levhası</label>
                            <input type="file" accept=".jpg,.pdf,.png" name="tax_plate" class="form-control" aria-label="file example" required>
                            <div class="invalid-feedback">Lütfen Vergi Levhanızı .pdf .jpg .png formatlarında bizimle paylaşın.</div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="rental_agreement" class="form-label">Kendi kiralama sözleşmeniz</label>
                            <input type="file" accept=".pdf,.doc,.docx" name="rental_agreement" class="form-control" aria-label="file example" required>
                            <div class="invalid-feedback">Lütfen Vergi Levhanızı .pdf .docx formatlarında bizimle paylaşın.</div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="company-our" class="form-label">Şirketinizden bahsedin</label>
                            <textarea name="company_our" class="form-control" id="company-our" rows="5" placeholder="Şu tarihten beri kiralama yapıyoruz, ekibimiz bu şekilde…" required><?php if (isset($company_information['company_our'])) {echo $company_information['company_our'];}  ?></textarea>
                            <div class="invalid-feedback">Lütfen şirketinizden bize bahsedin.</div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary px-5 rounded-5 float-end">İleri </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-5 col-sm-12">
                    <img src="<?php echo base_url('assets/image/company-information.png') ?>" class="w-100 my-auto" alt="">
                </div>
            </div>
        </div>
    </div>
</div>