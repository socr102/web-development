<div class="container mb-5">
    <div class="row">
        <div class="col-sm-12 px-0">
            <h1 class="fs-3 fw-bold mt-5 mb-0">Karavan360 Partner Başvurusu</h1>
            <div class="my-4">
                <ul class="list-unstyled d-flex">
                    <li><a class="btn btn-step px-5 disabled">Şirket Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#d1d1d1"/></svg></li>
                    <li><a class="btn btn-step px-5 disabled">Banka Bilgileri</a><svg class="mx-5" width="15.489" height="24" viewBox="0 0 15.489 24"><path d="M39.712,109.225l-10.2,10.2a1.792,1.792,0,0,1-2.542,0l-1.694-1.694a1.792,1.792,0,0,1,0-2.542l7.228-7.228-7.228-7.228a1.792,1.792,0,0,1,0-2.542l1.687-1.709a1.792,1.792,0,0,1,2.542,0l10.2,10.2A1.794,1.794,0,0,1,39.712,109.225Z" transform="translate(-24.75 -95.95)" fill="#d1d1d1"/></svg></li>
                    <li><a class="btn btn-step px-5">İletişim Bilgileri</a></li>
                </ul>
            </div>
        </div>
        <div class="card mb-5">
            <div class="row p-5">
                <div class="col-md-7 col-sm-12">
                    <form action="<?php echo base_url('register/createaccount') ?>" method="post" class="needs-validation row" novalidate enctype="multipart/form-data">
                        <div class="col-md-12 col-sm-12 mb-3">
                            <label for="email" class="form-label">E-posta adresi <e>(Hesabınız bu e-postayla oluşturulacak)</e></label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="ornek@mail.com" required>
                            <div class="invalid-feedback">
                                Lütfen e-posta adresinizi giriniz.
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 mb-3">
                            <label for="phone" class="form-label">Telefon numarası</label>
                            <input type="phone" class="form-control" name="phone" id="phone" placeholder="+90 555 555 55 55" required>
                            <div class="invalid-feedback">
                                Lütfen telefon numaranızı giriniz.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="website" class="form-label">Websitesi <e>(İsteğe bağlı)</e></label>
                            <input type="text" class="form-control" name="website" id="website" placeholder="website.com">
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="social_media" class="form-label">Sosyal Medya <e>(İsteğe bağlı)</e></label>
                            <input type="text" class="form-control" name="social_media" id="social_media">
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="password" class="form-label">Parola</label>
                            <input type="password" class="form-control" name="password" id="password" required>
                            <div class="invalid-feedback">
                                Lütfen parolanızı oluşturun.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 mb-3">
                            <label for="password-verify" class="form-label">Parolanızı doğrulayın</label>
                            <input type="password-verify" class="form-control" name="password-verify" id="password-verify" required>
                            <div class="invalid-feedback">
                                Lütfen parolanızı doğrulayın.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <a href="<?php echo base_url('register/bank-information') ?>" class="btn btn-secondary px-5 rounded-5 float-start"> Geri</a>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <button type="submit" class="btn btn-primary px-5 rounded-5 float-end">Başvuruyu Tamamla </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-5 col-sm-12">
                    <img src="<?php echo base_url('assets/image/company-information.png') ?>" class="w-100 my-auto" alt="">
                </div>
            </div>
        </div>
    </div>
</div>