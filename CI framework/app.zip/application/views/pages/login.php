<div class="container">
    <div class="row">
        <div class="col-sm-5 my-5 py-5 m-auto">
            <h1 class="fs-3 pb-3 fw-bold">Partner Girişi</h1>
            <div class="card p-4">
                <form action="<?php echo base_url('home/login') ?>" method="post" class="needs-validation" novalidate>
                    <div class="col-md-12 mb-3">
                        <label for="email" class="form-label">E-posta</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="ornek@mail.com" required>
                        <div class="invalid-feedback">
                            Lütfen e-posta adresinizi giriniz
                        </div>
                    </div>
                    <div class="col-md-12 mb-5">
                        <label for="password" class="form-label">Şifre</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="********" required>
                        <div class="invalid-feedback">
                            Lütfen şifrenizi giriniz
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Giriş Yap <svg width="19.389" height="18.389" viewBox="0 0 18.389 18.389"> <path d="M26.389,17.194a9.194,9.194,0,1,0-9.194,9.194A9.193,9.193,0,0,0,26.389,17.194Zm-16.609,0a7.415,7.415,0,1,1,7.415,7.415A7.413,7.413,0,0,1,9.78,17.194Zm2.669.741V16.453a.446.446,0,0,1,.445-.445h4.3V13.524a.446.446,0,0,1,.76-.315l3.67,3.67a.445.445,0,0,1,0,.63l-3.67,3.67a.445.445,0,0,1-.76-.315V18.381h-4.3A.446.446,0,0,1,12.449,17.936Z" transform="translate(-8 -8)"/> </svg></button>
                </form>
                <div class="mt-4">
                    <hr/><span class="divider-text">Ya da</span>
                </div>
                <a href="<?php echo base_url('register') ?>" class="btn btn-secondary w-100">Karavan360 Partneri Ol! <svg width="22.952" height="16.066" viewBox="0 0 22.952 16.066"> <path d="M3.443,38.886a2.3,2.3,0,1,0-2.3-2.3A2.3,2.3,0,0,0,3.443,38.886Zm16.066,0a2.3,2.3,0,1,0-2.3-2.3A2.3,2.3,0,0,0,19.509,38.886Zm1.148,1.148h-2.3a2.288,2.288,0,0,0-1.617.667,5.246,5.246,0,0,1,2.693,3.923H21.8a1.146,1.146,0,0,0,1.148-1.148V42.328A2.3,2.3,0,0,0,20.657,40.033Zm-9.181,0a4.017,4.017,0,1,0-4.017-4.017A4.015,4.015,0,0,0,11.476,40.033Zm2.754,1.148h-.3a5.546,5.546,0,0,1-4.913,0h-.3A4.132,4.132,0,0,0,4.59,45.312v1.033a1.722,1.722,0,0,0,1.721,1.721H16.64a1.722,1.722,0,0,0,1.721-1.721V45.312A4.132,4.132,0,0,0,14.23,41.181ZM6.208,40.7a2.288,2.288,0,0,0-1.617-.667H2.3a2.3,2.3,0,0,0-2.3,2.3v1.148a1.146,1.146,0,0,0,1.148,1.148H3.511A5.259,5.259,0,0,1,6.208,40.7Z" transform="translate(0 -32)"/> </svg></a>
            </div>
        </div>
    </div>
</div>