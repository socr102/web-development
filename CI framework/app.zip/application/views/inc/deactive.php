<div class="container my-5 py-5">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <div class="card p-5">
                <h1 class="fs-4">Merhaba!, <?php echo $userinformation->company_holder; ?></h1>
                <p>Siz, <b><?php echo $userinformation->company_name; ?></b> yetkilisi olmalısınız. Karavan 360 ailesine katılma isteğiniz bizi çok mutlu etti. Bu süreçte size hızlı bir şekilde yardımcı olmak istiyoruz.</p>
                <p>Gerekli bilgileri doğru ilettiğinizden emin olduğumuzda Karavan 360 hesabınızı aktif hale getireceğiz. Bu süreç genellikle 24 saat içerisinde tamamlanır. <a href="#">Detaylı Bilgi</a></p>
                <a href="" class="btn btn-primary w-100">Destek Talebi Oluştur.</a>
            </div>
        </div>
    </div>
</div>