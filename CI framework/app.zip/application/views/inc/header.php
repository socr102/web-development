<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karavan 360</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
</head>
<body>
    <header>
        <div class="container px-0">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid px-0">
                    <a class="navbar-brand" href="<?php echo base_url('home') ?>"><img src="<?php echo base_url('assets/image/logo.svg') ?>" height="50" alt="Karavan 360 Logo"></a>
                    <?php
                    
                    if ($this->session->userdata('userinformation')) {
                        if($this->session->userdata('userinformation')->status=='active'){
                            echo '
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mobile-support" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="mobile-support">
                    <ul class="navbar-nav ms-auto me-0 float-end mb-2 mb-lg-0">
                        <li class="nav-item me-3"><a class="nav-link active" aria-current="page" href="#">Rezervasyonlar</a></li>
                        <li class="nav-item me-3"><a class="nav-link active" aria-current="page" href="' . base_url('home/my-caravans') . '">Karavanlarım</a></li>
                        <li class="nav-item me-4"><a class="nav-link active" aria-current="page" href="#">Mesajlar</a></li>
                    </ul>
                    ';
                        }else {
                            echo "";
                        }
                    }
                    
                    ?>
                    <div class="dropdown ms-0">
                        <a <?php if ($this->session->userdata('userinformation')) {echo 'id="userdropdown" data-bs-toggle="dropdown" aria-expanded="false"';} ?> href="<?php if($this->uri->segment(1)=='register') {echo base_url('home');} elseif ($this->session->userdata('userinformation')) { echo '#';} else { echo base_url('register');} ?>" class="ms-auto px-4 btn btn-secondary"><svg width="24" height="24" viewBox="0 0 24 24"> <path d="M12,12.645a4.645,4.645,0,1,0,4.645,4.645A4.646,4.646,0,0,0,12,12.645Zm0,6.968a2.323,2.323,0,1,1,2.323-2.323A2.323,2.323,0,0,1,12,19.613ZM12,8A12,12,0,1,0,24,20,12,12,0,0,0,12,8Zm0,21.677a9.622,9.622,0,0,1-6.3-2.342,4.169,4.169,0,0,1,3.368-1.911A9.844,9.844,0,0,0,12,25.889a9.691,9.691,0,0,0,2.927-.465A4.181,4.181,0,0,1,18.3,27.335,9.622,9.622,0,0,1,12,29.677Zm7.873-4.069A6.418,6.418,0,0,0,14.787,23.1,14.521,14.521,0,0,1,12,23.561,14.6,14.6,0,0,1,9.213,23.1a6.432,6.432,0,0,0-5.085,2.511A9.673,9.673,0,1,1,21.677,20,9.608,9.608,0,0,1,19.873,25.608Z" transform="translate(0 -8)"/> </svg> <?php if($this->session->userdata('userinformation')) { echo $this->session->userdata('userinformation')->company_name;} elseif($this->uri->segment(1)=='register') {echo "Giriş Yap";} else { echo "Partner Ol";} ?></a>
                        <ul class="dropdown-menu" aria-labelledby="userdropdown">
    <?php if ($this->session->userdata('userinformation')->status=='active') {echo '<li><a class="dropdown-item" href="' . base_url('home/profile') . '">Profili Düzenle</a></li>';} ?>
    <li><a class="dropdown-item" href="<?php echo base_url('register/logout') ?>">Çıkış Yap</a></li>
  </ul>
                    </div>
                    
                    </div>
                </div>
            </nav>
        </div>
    </header>
    
