<?php
class Vt extends CI_Model {
	function checklogin($email,$password) {
		$result = $this
		->db
		->select('*')
		->from('users')
		->where('email', $email)
		->where('password', md5($password))
		->get()
		->row();
		return $result;
	}
}
?>